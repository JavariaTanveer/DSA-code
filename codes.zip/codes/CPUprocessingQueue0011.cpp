#include<iostream>
using namespace std;
template<class T>
class Queue
{
private:
	T* arr;
	int front;
	int rear;
	int size;
public:
	Queue()
	{
		front = -1;
		rear = -1;
		size = 10;
		arr = new T[size];
	}
	bool isfull()
	{
		if (rear == size - 1)
			return true;
		return false;
	}
	bool isEmpty()
	{
		if (front && rear == -1)
			return true;
		return false;
	}
	void psh1(T data)
	{
		if (!isfull())
		{
			if (front == -1)
			{
				front++;
			}
			rear++;
			arr[rear] = data;
		}
		else
		{
			T* temp = new T[size * 2];
			size *= 2;
			for (int i = 0; i < rear; i++)
			{
				temp[i] = arr[i];
			}
			delete[]arr;
			arr = temp;
			psh1(data);
		}
	}
	
	void push(T*data,int arrSize)
	{
		if (!isfull())
		{
			for (int i = 0; i < arrSize; i++)
			{
				if (front == -1)
				{
					front++;
				}
				rear++;
				arr[rear] = data[i];
			}
		}
		else
		{
			T* temp = new T[size * 2];
			size *= 2;
			for (int i = 0; i < rear; i++)
			{
				temp[i] = arr[i];
			}
			delete[]arr;
			arr = temp;
			push(data, arrSize);
		}
	}


	


	
	int pop()
	{
		if (!isEmpty())
		{
			T temp = arr[rear];
			if (front == rear)
			{
				front = rear = -1;
			}
			else
			{
				for (int i = 0; i < rear; i++)
				{
					arr[i] = arr[i + 1];
				}
				rear--;
			}
			return temp;
		}
		else
		{
			cerr << "empty" << endl;
			return -1;
		}
	}
	void display()
	{
		for (int i = 0; i <= rear; i++)
		{
			cout << arr[i] << " ";
		}
		cout << endl;
	}
	int starting()
	{
		if(!isEmpty())
			return arr[front];
		
	}
	void processing()
	{
		int count = 0;
		while (1)
		{
			T temp=starting();
			temp--;
			if (arr[rear] == 0)
			{
				rear--;
			}
			pop();
			psh1(temp);
			count++;
			cout << "count# " << count << "   :";
			display();
			if (arr[front]==0)
			{
				break;
			}
		}
	}
};
int main()
{
	cout << "----------------------------FIRST IN FIRST OUT CPU MULTI-PROCESSING---------------------------" << endl;
	Queue<int>que;
	int size = 0;
	cout << "enter the size of the elements: ";
	cin >> size;
	int* arr = new int[size];
	for (int i = 0; i < size; i++)
	{
		cin >> arr[i];
	}
	
	que.push(arr,size);
	que.processing();

	//que.processing();


}