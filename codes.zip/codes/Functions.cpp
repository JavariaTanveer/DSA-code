#include<iostream>
#include<string>
#include"Student.h"
#include"Stack.h"
using namespace std;


Student::Student()
{
	Name = "";
	Marks = 0;
	next = nullptr;
}
Student::Student(string Name, int Marks)
{
	this->Name = Name;
	this->Marks = Marks;
	next = nullptr;
}
void Student::setName(string Name)
{
	this->Name = Name;
}
string Student::getName()
{
	return Name;
}
void Student::setMarks(int Marks)
{
	this->Marks = Marks;
}
int Student::getMarks()
{
	return Marks;
}
void Student::setnext(Student* next)
{

	this->next = next;
}
Student* Student::getnext()
{
	return next;
}

Stack::Stack()
{
	headStudent = nullptr;
}
void Stack::top()
{
	cout << headStudent->getMarks();
}

void Stack::push(string Name, int Marks)
{
	Student *New = new Student;
	New->setName(Name);
	New->setMarks(Marks);
	New->setnext(headStudent);
	headStudent = New;
}

void Stack::pop()
{
	if (headStudent == nullptr)
	{
		cout << "List is empty" << endl;
	}
	Student* temp = headStudent;

	headStudent = headStudent->getnext();
	delete temp;
}

void Stack::sorting()
{
	Student* temp1 = headStudent;
	Student* i;
	Student* j;
	string tempname;
	int temp;
	for (i = this->headStudent; i->getnext() != NULL; i = i->getnext())
	{
		for (j = i->getnext(); j != NULL; j=j->getnext())
		{
			if ((i->getMarks()) < (j->getMarks()))
			{
				tempname = i->getName();
				temp = i->getMarks();
				i->setName(j->getName());
				i->setMarks(j->getMarks());
				j->setName((tempname));
				j->setMarks(temp);
			}
		}
	}
	cout << "Sorted Name and Marks are : " << endl;
	while (temp1 != nullptr)
	{
		cout << temp1->getName() << "  " << temp1->getMarks() << "  " << endl;
		temp1 = temp1->getnext();
	}
}
void Stack::Display()
{
	if (headStudent == nullptr)
		cout << "Linked list is empty" << endl;
	else
	{
		Student* temp = headStudent;
		cout << "Name and Marks are : " << endl;
		while (temp != nullptr)
		{
			cout << temp->getName() << "  " << temp->getMarks() << "  " << endl;
			temp = temp->getnext();
		}
	}
}

