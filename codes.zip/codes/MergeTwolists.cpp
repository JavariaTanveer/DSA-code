#include<iostream>
using namespace std;
class Node
{
public:
	Node* next;
	int data;
Node()
{
    data=0;
    next=NULL;
}
Node(int data)
{
    this->data=data;
    next=NULL;
}
void setdata(int data)
{
    this->data=data;
}
int getdata()
{
    return data;
}
void setnext(Node* next)
{
  this->next=next;  
}
Node* getNext()
{
return next;
}
};
class LinkedList
{
private:
    
    Node *tail;
public:
	Node *head;
    LinkedList()
    {
        head=NULL;
        tail=NULL;
    }
    void insertAtStart(float data)
    {
        Node *N = new Node;
        N->setdata(data);
        N->setnext(head);
        if(head==NULL)
        {
            tail = N;
        }
        head = N;
    }
    void insertAtEnd(float data)
    {
        Node *N = new Node;
       N->setdata(data);
        N->setnext(NULL);
        if(head == NULL)
        {
            head = N;
            tail = N;
        }
        else
        {
            tail->setnext(N);
            tail = N;
        }
    }
    void display()
    {
        if(head==NULL)
        {
            cout<<"List is empty"<<endl;
        }
        else
        {
            Node *temp = head;
            while(temp!=NULL)
            {
                cout<<temp->getdata()<<" ";
                temp = temp->getNext();
            }
        }
    }
    void deleteFromStart()
    {
        if(head == NULL)
        {
            cout<<"List is empty"<<endl;
        }
        else
        {
            Node *temp = head;
            if(head==tail)
            {
                head=tail=NULL;
                delete temp;
            }
            else
            {
                head = head->getNext();
                delete temp;
            }
        }
    }
    void deleteFromEnd()
    {
        if(head == NULL)
        {
            cout<<"List is empty"<<endl;
        }
        else
        {
            Node *temp = head;

            if(head==tail)
            {
                head=tail=NULL;
                delete temp;
            }
            else
            {
                while(temp->getNext()!=tail)
                {
                    temp = temp->getNext();
                }
                tail = temp;
                temp = temp->getNext();
                delete temp;
                tail->setnext(NULL);
            }
        }
    }
  void reverse()
    {
        Node *temp = head;
        Node *prev = NULL;
        Node *next = NULL;
        while (temp != NULL)
        {
            next = temp->getNext();
            temp->setnext(prev);
            prev = temp;
            temp = next;
        }
        head = prev;
    }



void mergesort(Node* &H1, Node* &H2)
{
    Node* temp;
	if (H1 == NULL)
	{
		H1 = H2;
	}
	temp = H1;
	while (temp->next != NULL)
	{
		temp = temp->next;
	}
	temp->next = H2;
}

void Sort(Node* head)
	{
		Node* current = head;
		int count = 0;
		while (current!=NULL)
		{
			current = current->next;
			count++;
		}
		current = head;
		for (int i = 0; i < count; i++)
		{
			while (current->next)
			{
				if (current->data < current->next->data)
				{
					int temp = current->data;
					current->data = current->next->data;
					current->next->data = temp;
				}
				else {
					current = current->next;
				}
			}
			current = head;
		}
	}

};

int main()
{
    LinkedList list,list2;
    list.insertAtStart(10);
	list.insertAtStart(20);
	list.insertAtEnd(15);
	list.insertAtEnd(150);
    /*cout<<"List before reversing---->";
    list.display();
    cout<<endl;
    cout<<"List after reversing---->";
    list.reverse();
    list.display();
    cout<<endl;*/
    
    list2.insertAtStart(5);
    list2.insertAtStart(4);
    list2.insertAtEnd(7);
    list2.insertAtEnd(9);
    cout<<" First Linked List :";
    list.display();
    cout<<"\n Second Linked List :";
    list2.display();
    list.mergesort(list.head,list2.head);
    cout<<"\n After Merging First & Second :";;
    list.display();
    list.Sort(list.head);
    cout<<" \nMerged Linklist in Descending Order :";
    list.display();
    return 0;
}
