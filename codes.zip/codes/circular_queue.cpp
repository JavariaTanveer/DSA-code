#include<iostream>
using namespace std;
template<class T>
class Queue{
	T* array;
	int front;
	int rear;
	int max_size;
public:
	Queue(){
		max_size=50;
		front=-1;
		rear=-1;
		array=new T[max_size];
	}
	Queue(int front,int rear,int max_size,T* array){
		this->front=front;
		this->rear=rear;
		this->max_size=max_size;
		this->array=array;
	}
	void set_array_size(int max_size){
		this->max_size=max_size;
		array=new T[max_size];
		front=rear=-1;
	}
	void enqueue(T value){
		if(is_full())
			cout<<"your queue is overflow"<<endl;
		else if(is_empty()){
			front++;
			rear++;
			array[rear]=value;
		}
		else {
			rear=(rear+1)%max_size;
			array[rear]=value;
		}
	}
	T dequeue(){
		if(is_empty())
			cout<<"your queue is underflow"<<endl;
		else if(front==rear){
			T x= array[front];
			front=rear=-1;
			return x;
		}
		else{
			T x=array[front];
			front=(front+1)%max_size;
			return x;
		}
	}
	bool is_empty(){
		if(front==-1 && rear==-1)
			return true;
		return false;
	}
	bool is_full(){
		if((rear+1)%max_size==front)
			return true;
		return false;
	}
	void print(){
		if(is_empty())
			cout<<"array is empty"<<endl;
		else{
			for(int i=front;i<(rear+1)%max_size;i++)
				cout<<array[i]<<"\t";
			cout<<endl;
		}
	}
	T peak_value(){return array[rear];}
	~Queue(){
		front=rear=-1;
		delete[] array;
		array=0;
	}
};
int main(){
	Queue<int> east_west_obj,north_south_obj;
	for(int i=0;i<40;i++){//randomly taken 40 seconds for the trafic to in and out
	//when light turns green for east_west direction and turns red for the north south direction then it will dequeue the car and enqueue the cars ..
	// let car be consider as 1 ,so ....
		int x=east_west_obj.dequeue();
		north_south_obj.enqueue(1);
	}
	for(int i=0;i<40;i++){//randomly taken 40 seconds for the trafic to in and out
	//when light turns red for east_west direction and turns green for the north south direction 
		int x=north_south_obj.dequeue();
		east_west_obj.enqueue(1);
	}
	cout<<"cars left in east west direction: " <<endl;
	east_west_obj.print();
	cout<<"cars left in north south direction: "<<endl;
	north_south_obj.print();
	
	system("pause");
	return 0;
}